function bloomFilter = initializeBloomFilter(n, k)
    bloomFilter = zeros(1, n);
end

O exercicio 4.1.3 e 4.1.4 não fiz sozinho, mas depois de ver uma possivel resolução consegui percebê-los
